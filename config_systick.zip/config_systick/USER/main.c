#include"stm32f10x.h"
#include"systick.h"
#include"LED.h"

int main(void)
{
 LED_Config();
 while(1)
 {
   GPIOB->ODR ^=1<<5;
   systick_delay_MS(500);
 }
}
