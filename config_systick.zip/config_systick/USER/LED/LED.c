#include"LED.h"

void LED_Config(void)
{
 GPIO_InitTypeDef GPIO_struct;
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
 GPIO_struct.GPIO_Mode=GPIO_Mode_IPD;
 GPIO_struct.GPIO_Pin=GPIO_Pin_5;
 GPIO_struct.GPIO_Speed=GPIO_Speed_50MHz;
 
 GPIO_DeInit(GPIOB);
 GPIO_Init(GPIOB,&GPIO_struct);

}
