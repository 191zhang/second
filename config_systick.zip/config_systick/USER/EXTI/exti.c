#include"exti.h"

static void NVIC_Config(void)
{
  NVIC_InitTypeDef NVIC_struct;
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
	NVIC_struct.NVIC_IRQChannel= EXTI0_IRQn;
	NVIC_struct.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_struct.NVIC_IRQChannelSubPriority=1;
	NVIC_struct.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_struct);
}


void KEY_Config(void)
{
 EXTI_InitTypeDef EXTI_struct;
 //初始化PA0
 GPIO_InitTypeDef GPIO_struct;
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
 GPIO_struct.GPIO_Mode=GPIO_Mode_IPD;
 GPIO_struct.GPIO_Pin=GPIO_Pin_0;
 GPIO_struct.GPIO_Speed=GPIO_Speed_50MHz;
 GPIO_DeInit(GPIOA);
 GPIO_Init(GPIOA,&GPIO_struct);
 //配置NVIC
  NVIC_Config();
 //配置EXTI
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource0);
	EXTI_struct.EXTI_Line=EXTI_Line0;
	EXTI_struct.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_struct.EXTI_Trigger=EXTI_Trigger_Rising;
	EXTI_struct.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_struct);
}