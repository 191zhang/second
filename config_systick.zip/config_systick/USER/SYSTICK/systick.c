#include"systick.h"


void delay_MS(u32 count)
{
 u32 i;
 SysTick_Config(72000);
 
 for(i=0;i<count;i++)
 {
  while(!((SysTick->CTRL)&(1<<16)));
 }
 SysTick->CTRL=0;
}
